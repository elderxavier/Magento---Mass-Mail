<?php

class ElderXavier_Massmail_Helper_Data extends Mage_Core_Helper_Abstract {	

	public function getIdsArray()
	{
		try {
			$read = Mage::getSingleton('core/resource')->getConnection('core_read');
			$sql        = 'SELECT massmail_id FROM massmail';
			$rows       = $read->fetchAll($sql);
			return $rows;
		} catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());                
                return;
        }
	}


	public function getTemplatesArray()
	{
		try {
			$resource = Mage::getSingleton('core/resource');
			$readConnection = $resource->getConnection('core_read');
			$query = 'SELECT * FROM massmail';
			$sql   = $readConnection->prepare($query);		
			return $sql;
		} catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());                
                return;
        }
	}

	

}
