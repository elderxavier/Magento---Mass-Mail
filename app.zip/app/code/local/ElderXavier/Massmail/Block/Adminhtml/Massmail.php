<?php

class ElderXavier_Massmail_Block_Adminhtml_Massmail extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller = 'adminhtml_massmail';
        $this->_blockGroup = 'massmail';
        $this->_headerText = Mage::helper('massmail')->__('Item Manager');
        $this->_addButtonLabel = Mage::helper('massmail')->__('Add Item');
        $this->_addButton('buton', array(
            'label'     => Mage::helper('massmail')->__('New'),
            'onclick'   => 'setLocation(\'' . $this->getUrl('*/*/new') . '\')',
            'class'     => 'delete_button'
        ), -1, 100, 'header');
        /*pagina de testes*/
        $this->_addButton('buton_teste', array(
            'label'     => Mage::helper('massmail')->__('Teste'),
            'onclick'   => 'setLocation(\'' . $this->getUrl('*/*/teste') . '\')',
            'class'     => 'delete_button'
        ), 1, 100, 'header');

        parent::__construct();
    }
}