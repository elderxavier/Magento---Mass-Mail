<?php
 
class ElderXavier_Massmail_Adminhtml_MassmailController extends Mage_Adminhtml_Controller_Action
{
 
    protected function _initAction()
    {
        $this->loadLayout()
            ->_setActiveMenu('massmail/send')
            ->_addBreadcrumb(Mage::helper('adminhtml')->__('Items Manager'), Mage::helper('adminhtml')->__('Mass Mail'));                        
        return $this;
    }   
   
    public function indexAction() {
        $this->_initAction();                              
        $this->getLayout()->getBlock('head')->setTitle($this->__('Mass Mail / Send'));
        $this->renderLayout();
    }
    
     public function listAction()
    {
        echo "list";
       // $this->_forward('edit');
        
        $this->_initAction();         
        $this->loadLayout()
            ->_setActiveMenu('massmail/edit')
            ->_addBreadcrumb(Mage::helper('adminhtml')->__('Items Manager'), Mage::helper('adminhtml')->__('Mass Mail'));                                                                      
            $this->_addContent($this->getLayout()->createBlock('massmail/adminhtml_list'));             
            $this->renderLayout();            
    }

    public function editAction()
    { 
        $massmailId     = $this->getRequest()->getParam('id');
        $massmailModel  = Mage::getModel('massmail/massmail')->load($massmailId);
        
        Mage::register('massmail_data', $massmailModel);
        $this->_initAction();  
            $this->loadLayout();
            if (Mage::getSingleton('cms/wysiwyg_config')->isEnabled()) {
                $this->getLayout()->getBlock('head')->setCanLoadTinyMce(true);
            }
            $this->_setActiveMenu('massmail/items');           
            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Item Manager'), Mage::helper('adminhtml')->__('Item Manager'));
            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Item News'), Mage::helper('adminhtml')->__('Item News'));
           
            $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);  
            
            //$this->_addContent($this->getLayout()->createBlock('massmail/adminhtml_list_edit_tab_form'));
            $this->_addContent($this->getLayout()->createBlock('massmail/adminhtml_list_edit'))
                 ->_addLeft($this->getLayout()->createBlock('massmail/adminhtml_list_edit_tabs'));

            /*$this->_addContent($this->getLayout()->createBlock('massmail/adminhtml_list_edit'))
                 ->_addLeft($this->getLayout()->createBlock('massmail/adminhtml_list_edit_tabs'));
              */ 
            $this->getLayout()->getBlock('head')->setTitle($this->__('Mass Mail / Edit'));
            $this->renderLayout();
       
    }
   
    public function newAction()
    {
        //$this->_forward('list');
        $this->_initAction();         
        $this->loadLayout()
            ->_setActiveMenu('massmail/edit')
            ->_addBreadcrumb(Mage::helper('adminhtml')->__('Items Manager'), Mage::helper('adminhtml')->__('Mass Mail'));            
           
            if (Mage::getSingleton('cms/wysiwyg_config')->isEnabled()) {
                $this->getLayout()->getBlock('head')->setCanLoadTinyMce(true);
            }
            
            $this->getLayout()->getBlock('head')->setTitle($this->__('Mass Mail / New'));            
            $this->_addContent($this->getLayout()->createBlock('massmail/adminhtml_massmail_edit'));            
            $this->renderLayout();       
    }
            
    
   
    public function saveAction()
    {        
        if ( $this->getRequest()->getPost() ) {
            try {                                                
                $massmailModel = Mage::getModel('massmail/massmail');
               
                $massmailModel
                    //->setId($this->getRequest()->getParam('id'))
                    ->setData('template_id',$this->getRequest()->getPost('template_id'))
                    ->setData('template_name',$this->getRequest()->getPost('template_name'))
                    ->setData('fromemail',$this->getRequest()->getPost('fromemail'))
                    ->setData('reply',$this->getRequest()->getPost('reply'))                    
                    ->setData('subject',$this->getRequest()->getPost('subject'))
                    ->setData('description',$this->getRequest()->getPost('description'))
                    ->setData('created_time',date('Y-m-d H:i:s'))
                    ->save();                                    
                $this->_redirect('*/*/list');
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Template was successfully saved'));
                //Mage::getSingleton('adminhtml/session')->setmassmailData(false);                
            
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                //Mage::getSingleton('adminhtml/session')->setmassmailData($this->getRequest()->getPost());                
            }
        }        
    }       

    public function editsaveAction()
    {        
        echo 'ok editsaveAction';
        //$postData = $this->getRequest()->getPost();
        echo '<pre>', print_r($_REQUEST);
        echo '<pre>', print_r(Mage::registry('massmail_data')->getData());
        if ( $this->getRequest()->getPost() ) {
            try {                                
                /*
                $massmailModel = Mage::getModel('massmail/massmail');
               
                $massmailModel
                    ->setId($this->getRequest()->getParam('id'))
                    ->setData('template_id',$this->getRequest()->getPost('template_id'))
                    ->setData('template_name',$this->getRequest()->getPost('template_name'))
                    ->setData('fromemail',$this->getRequest()->getPost('fromemail'))
                    ->setData('reply',$this->getRequest()->getPost('reply'))                    
                    ->setData('subject',$this->getRequest()->getPost('subject'))
                    ->setData('description',$this->getRequest()->getPost('description'))
                    ->setData('created_time',date('Y-m-d H:i:s'))
                    ->save();*/                                    
                //$this->_redirect('*/*/list');
                //Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Template was successfully saved'));
                //Mage::getSingleton('adminhtml/session')->setmassmailData(false);                
            
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                //Mage::getSingleton('adminhtml/session')->setmassmailData($this->getRequest()->getPost());                
            }
        }        
    }       
    /*public function gridAction()
    {
        $this->loadLayout();
        $this->getResponse()->setBody(
               $this->getLayout()->createBlock('massmail/adminhtml_massmail_grid')->toHtml()
        );
    }
    */
    public function testeAction()
    {
        echo "ok teste<br>";        
        //$data  = $sql->fetchAll(PDO::FETCH_COLUMN, 0);
        
        /*$sql = Mage::helper('massmail')->getTemplatesArray();
        $sql->execute();
        $data  = $sql;
        $data  = $sql->fetchAll();
        */
        //echo '<pre>',print_r($data);

        //$collection = Mage::getModel('massmail/massmail')->getCollection();
        $collection = Mage::getModel('massmail/massmail');
        echo '<pre>',print_r($collection->getCollection());

        //print_r($data->fetchAll(PDO::FETCH_COLUMN, 0));
        
        //$datab  = $sql->fetchAll(PDO::FETCH_COLUMN, 1);
        //print_r($datab);
       // echo '<pre>',print_r($_REQUEST);
        //echo '<pre>',print_r($_REQUEST['massaction']);
        
        //var_dump(Mage::helper('massmail')->getTemplatesArray()->fetchAll());
    }
}