# Magento-Mass-Mail

Magneto module for sending mass email (building)

